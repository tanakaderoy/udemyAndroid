package com.Tanaka.exampleapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    Integer num = 0;
    public void clickFunction(View view){
        System.out.println("CLicked");
        EditText nameEditText = (EditText) findViewById(R.id.nameEditText);
        Log.i("Values", nameEditText.getText().toString());

        Log.i("Info", "Hi i have been clicked");
        Toast.makeText(this, "Hi there! "+nameEditText.getText().toString(), Toast.LENGTH_SHORT).show();

    }
    public void changeCat(View view){
        ImageView catImageView = (ImageView) findViewById(R.id.catImageView);

        if(num % 2 == 0) {
            catImageView.setImageResource(R.drawable.cat2);
            num +=1;
        }else{
            catImageView.setImageResource(R.drawable.cat1);
            num+=1;
        }

    }
}
